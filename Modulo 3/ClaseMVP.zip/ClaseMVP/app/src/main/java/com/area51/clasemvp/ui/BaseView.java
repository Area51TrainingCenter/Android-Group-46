package com.area51.clasemvp.ui;

public interface BaseView {
    void init();
}
