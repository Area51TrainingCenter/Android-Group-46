package com.area51.clasemvp.ui;

import android.support.v7.app.AppCompatActivity;

public class BaseActivity extends AppCompatActivity {
}
